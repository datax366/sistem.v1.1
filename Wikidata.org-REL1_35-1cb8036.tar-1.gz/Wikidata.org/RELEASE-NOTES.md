﻿These are the release notes for the [Wikidata.org extension](README.md).

## Version 1.0.0

Initial release with these features:

* New css classes to style badges with specific icons.
