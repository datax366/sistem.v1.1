Wikidata.org
============

Configuration for and customizations to Wikibase that are specific to wikidata.org

Issues and tasks are tracked on [Phabricator](https://phabricator.wikimedia.org/project/view/125/)!
